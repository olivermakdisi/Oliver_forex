import os
import json
import smtplib
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from email.message import EmailMessage

import streamlit as st

# -------------------- APP SETTINGS --------------------
EMAIL_TO = "olivermakdisi12@gmail.com"
PAIRS = ["EUR/USD", "GBP/USD", "USD/JPY", "USD/CHF",
         "AUD/USD", "USD/CAD", "NZD/USD"]

START_BALANCE = 500.0
DEMO_RESULT_AMOUNT = 5.0
INTERVAL = "1min"
CANDLE_COUNT = 60
TRADE_DURATION_MINUTES = 2

st.set_page_config(page_title="Oliver Forex", page_icon="📈", layout="wide")

def get_secret(name, default=""):
    try:
        return st.secrets.get(name, os.getenv(name, default))
    except Exception:
        return os.getenv(name, default)

def http_json(url, payload=None):
    data = None
    headers = {"User-Agent": "OliverForexPaper/1.0"}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(request, timeout=20) as response:
        return json.loads(response.read().decode("utf-8"))

def notify(message):
    sent = []
    token = get_secret("TELEGRAM_BOT_TOKEN")
    chat_id = get_secret("TELEGRAM_CHAT_ID")
    if token and chat_id:
        try:
            http_json(
                f"https://api.telegram.org/bot{token}/sendMessage",
                {"chat_id": chat_id, "text": message},
            )
            sent.append("Telegram")
        except Exception as exc:
            st.warning(f"تعذر إرسال Telegram: {exc}")

    email_from = get_secret("TRADING_EMAIL")
    email_password = get_secret("TRADING_EMAIL_APP_PASSWORD")
    if email_from and email_password:
        try:
            msg = EmailMessage()
            msg["Subject"] = "Oliver Forex - Paper Trading Alert"
            msg["From"] = email_from
            msg["To"] = EMAIL_TO
            msg.set_content(message)
            with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=20) as server:
                server.login(email_from, email_password)
                server.send_message(msg)
            sent.append("Email")
        except Exception as exc:
            st.warning(f"تعذر إرسال البريد: {exc}")
    return sent

def get_candles(pair):
    api_key = get_secret("TWELVE_DATA_API_KEY")
    if not api_key:
        raise RuntimeError("أضف TWELVE_DATA_API_KEY في Streamlit Secrets.")
    params = urllib.parse.urlencode({
        "symbol": pair,
        "interval": INTERVAL,
        "outputsize": CANDLE_COUNT,
        "apikey": api_key,
        "format": "JSON",
        "timezone": "UTC",
    })
    data = http_json("https://api.twelvedata.com/time_series?" + params)
    if "values" not in data:
        raise RuntimeError(data.get("message", str(data)))
    values = list(reversed(data["values"]))
    return [{"datetime": x["datetime"], "close": float(x["close"])}
            for x in values]

def ema(values, period):
    multiplier = 2.0 / (period + 1)
    result = values[0]
    for value in values[1:]:
        result = value * multiplier + result * (1.0 - multiplier)
    return result

def rsi(values, period=14):
    recent = values[-(period + 1):]
    gains = losses = 0.0
    for i in range(1, len(recent)):
        change = recent[i] - recent[i - 1]
        if change > 0:
            gains += change
        else:
            losses -= change
    avg_gain, avg_loss = gains / period, losses / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))

def analyze(pair):
    candles = get_candles(pair)
    closes = [x["close"] for x in candles[:-1]]  # ignore forming candle
    if len(closes) < 22:
        return None
    fast = ema(closes[-30:], 9)
    slow = ema(closes[-30:], 21)
    strength = rsi(closes, 14)
    if fast > slow and 50 < strength < 70:
        direction = "BUY"
    elif fast < slow and 30 < strength < 50:
        direction = "SELL"
    else:
        return None
    return {
        "pair": pair,
        "direction": direction,
        "entry": closes[-1],
        "rsi": round(strength, 1),
        "reason": f"EMA9 {'>' if direction == 'BUY' else '<'} EMA21; RSI {strength:.1f}",
        "created": datetime.now(timezone.utc),
    }

# -------------------- SESSION STATE --------------------
if "balance" not in st.session_state:
    st.session_state.balance = START_BALANCE
if "signals" not in st.session_state:
    st.session_state.signals = []
if "pending" not in st.session_state:
    st.session_state.pending = []
if "results" not in st.session_state:
    st.session_state.results = []

# -------------------- UI --------------------
st.title("📈 Oliver Forex")
st.caption("لوحة إشارات فوركس تجريبية — لا تنفذ صفقات حقيقية ولا تتصل بوسيط تداول.")

col1, col2, col3 = st.columns(3)
col1.metric("الرصيد الافتراضي", f"${st.session_state.balance:,.2f}")
col2.metric("عدد الإشارات", len(st.session_state.signals))
col3.metric("النتائج المسجلة", len(st.session_state.results))

st.info("وضع تجريبي فقط: الرصيد 500$ افتراضي. كل نتيجة WIN تضيف 5$ وكل LOSS تخصم 5$ لأغراض المحاكاة فقط.")

with st.sidebar:
    st.header("الإعدادات")
    selected_pairs = st.multiselect("أزواج الفوركس", PAIRS, default=PAIRS[:3])
    st.caption("كل زوج يحتاج طلب بيانات من Twelve Data. راجع حدود خطتك قبل فحص عدة أزواج.")
    st.write("إشعارات البريد إلى:")
    st.code(EMAIL_TO)
    st.caption("إعداد مفاتيح API موجود في Streamlit → App settings → Secrets.")

left, right = st.columns(2)
with left:
    scan_clicked = st.button("🔎 فحص السوق الآن", type="primary", use_container_width=True)
with right:
    check_clicked = st.button("⏱️ تقييم الإشارات المستحقة", use_container_width=True)

if scan_clicked:
    if not selected_pairs:
        st.warning("اختر زوجاً واحداً على الأقل.")
    else:
        found = []
        progress = st.progress(0)
        status = st.empty()
        for index, pair in enumerate(selected_pairs):
            status.write(f"يتم فحص {pair} ...")
            try:
                signal = analyze(pair)
                if signal:
                    found.append(signal)
            except Exception as exc:
                st.warning(f"{pair}: {exc}")
            progress.progress((index + 1) / len(selected_pairs))

        if found:
            # Send all qualifying signals, not a claim that any is guaranteed.
            for signal in found:
                signal["number"] = len(st.session_state.signals) + 1
                signal["due"] = signal["created"] + timedelta(minutes=TRADE_DURATION_MINUTES)
                st.session_state.signals.insert(0, signal)
                st.session_state.pending.append(signal)
                msg = (
                    f"FOREX PAPER SIGNAL #{signal['number']}\\n"
                    f"Pair: {signal['pair']}\\n"
                    f"Action: {signal['direction']}\\n"
                    f"Reference price: {signal['entry']}\\n"
                    f"Reason: {signal['reason']}\\n"
                    "PAPER ONLY - not a live trade."
                )
                channels = notify(msg)
                signal["notified"] = ", ".join(channels) if channels else "لم يتم إعداد قناة إشعار"
            st.success(f"تم العثور على {len(found)} إشارة. راجع الجدول أدناه.")
        else:
            st.info("لم تظهر إشارات حسب شروط EMA وRSI الحالية.")
        status.empty()
        progress.empty()

if check_clicked:
    now = datetime.now(timezone.utc)
    due_items = [x for x in st.session_state.pending if now >= x["due"]]
    if not due_items:
        st.info("لا توجد إشارات مستحقة للتقييم بعد. انتظر دقيقتين على الأقل.")
    else:
        completed = []
        for signal in due_items:
            try:
                candles = get_candles(signal["pair"])
                close_price = candles[-2]["close"]
                is_buy = signal["direction"] == "BUY"
                if close_price == signal["entry"]:
                    result = "DRAW"
                elif (close_price > signal["entry"]) == is_buy:
                    result = "WIN"
                    st.session_state.balance += DEMO_RESULT_AMOUNT
                else:
                    result = "LOSS"
                    st.session_state.balance -= DEMO_RESULT_AMOUNT
                record = {
                    "number": signal["number"],
                    "pair": signal["pair"],
                    "direction": signal["direction"],
                    "entry": signal["entry"],
                    "close": close_price,
                    "result": result,
                    "time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
                }
                st.session_state.results.insert(0, record)
                completed.append(signal)
                notify(
                    f"FOREX PAPER RESULT #{signal['number']}\\n"
                    f"{signal['pair']} {signal['direction']}\\n"
                    f"Entry: {signal['entry']}\\nClose: {close_price}\\n"
                    f"Result: {result}\\nVirtual balance: ${st.session_state.balance:.2f}"
                )
            except Exception as exc:
                st.warning(f"تعذر تقييم الإشارة {signal['number']}: {exc}")
        st.session_state.pending = [x for x in st.session_state.pending if x not in completed]
        st.success(f"تم تقييم {len(completed)} إشارة.")

st.subheader("آخر إشارات السوق")
if st.session_state.signals:
    rows = []
    for s in st.session_state.signals[:30]:
        rows.append({
            "#": s["number"],
            "الزوج": s["pair"],
            "الاتجاه": s["direction"],
            "السعر المرجعي": s["entry"],
            "RSI": s["rsi"],
            "وقت الإشارة (UTC)": s["created"].strftime("%H:%M:%S"),
            "الإشعار": s.get("notified", "—"),
        })
    st.dataframe(rows, use_container_width=True, hide_index=True)
else:
    st.write("لا توجد إشارات بعد. اضغط «فحص السوق الآن».")

st.subheader("سجل النتائج التجريبية")
if st.session_state.results:
    st.dataframe(st.session_state.results, use_container_width=True, hide_index=True)
else:
    st.write("لم يتم تسجيل نتائج بعد.")

st.caption("تنبيه: بيانات السوق ومؤشرات التحليل قد تتأخر أو تخطئ. نتائج المحاكاة لا تمثل أرباحاً حقيقية أو توقعاً مضموناً. حالة الجلسة قد تُصفّر عند إعادة تشغيل التطبيق.")
