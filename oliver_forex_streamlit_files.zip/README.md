# Oliver Forex (Paper Trading)

واجهة Streamlit لإشارات أزواج الفوركس الرئيسية، مبنية على EMA 9 / EMA 21 و RSI.

## مهم
- التطبيق تجريبي فقط ولا يرسل أوامر إلى وسيط تداول.
- الرصيد الافتراضي يبدأ من 500 دولار.
- نتيجة WIN تضيف 5 دولارات افتراضياً وLOSS تخصم 5 دولارات؛ هذا مجرد سجل محاكاة وليس P&L حقيقياً.
- بيانات الأسعار تأتي من Twelve Data، وقد تخضع لحدود الاستخدام في خطتك.
- بيانات الجلسة قد تختفي عند إعادة تشغيل التطبيق.

## الملفات
- `app.py`: تطبيق Streamlit.
- `requirements.txt`: المكتبات المطلوبة.

## تشغيل محلي
```bash
pip install -r requirements.txt
streamlit run app.py
```

## إعداد Streamlit Community Cloud
1. ارفع `app.py` و`requirements.txt` إلى مستودع GitHub.
2. في Streamlit Community Cloud اختر المستودع والفرع وملف `app.py`.
3. من إعدادات التطبيق افتح **Secrets** وأضف القيم التالية:

```toml
TWELVE_DATA_API_KEY = "YOUR_TWELVE_DATA_KEY"
TELEGRAM_BOT_TOKEN = "YOUR_NEW_TELEGRAM_BOT_TOKEN"
TELEGRAM_CHAT_ID = "YOUR_TELEGRAM_CHAT_ID"
TRADING_EMAIL = "your_sender_gmail@gmail.com"
TRADING_EMAIL_APP_PASSWORD = "YOUR_GMAIL_APP_PASSWORD"
```

`TRADING_EMAIL` هو حساب Gmail المرسل، أما المستلم فهو `olivermakdisi12@gmail.com` داخل التطبيق.

لا تضع المفاتيح في GitHub أو داخل الكود. إذا سبق أن شاركت Telegram token، ألغِه وأنشئ واحداً جديداً من BotFather.
